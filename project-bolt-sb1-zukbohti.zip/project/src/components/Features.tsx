import React from 'react';
import { Heart, Users, Clock, MessageCircle } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: <Heart className="h-8 w-8 text-emerald-600" />,
      title: 'Atendimento Humanizado',
      description: 'Cuidado personalizado e acolhedor para cada paciente'
    },
    {
      icon: <Users className="h-8 w-8 text-emerald-600" />,
      title: 'Equipe Especializada',
      description: 'Profissionais experientes e altamente qualificados'
    },
    {
      icon: <Clock className="h-8 w-8 text-emerald-600" />,
      title: 'Horários Flexíveis',
      description: 'Atendimentos presenciais e online em horários convenientes'
    },
    {
      icon: <MessageCircle className="h-8 w-8 text-emerald-600" />,
      title: 'Primeira Consulta',
      description: 'Sessão inicial para conhecer melhor suas necessidades'
    }
  ];

  return (
    <div className="bg-gray-50 py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-serif text-gray-900">
            Por que nos escolher?
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Comprometidos com seu bem-estar emocional
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Features;