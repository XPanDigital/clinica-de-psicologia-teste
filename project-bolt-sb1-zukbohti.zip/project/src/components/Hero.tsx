import React from 'react';
import { Calendar } from 'lucide-react';

const Hero = () => {
  return (
    <div className="relative min-h-screen flex items-center justify-center">
      {/* Background Image */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
        }}
      >
        {/* Overlay */}
        <div className="absolute inset-0 bg-black/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
        <h1 className="text-5xl font-serif text-white mb-8">
          Encontre equilíbrio e bem-estar emocional
        </h1>
        <p className="text-xl text-gray-200 mb-12 max-w-3xl mx-auto">
          Atendimento psicológico humanizado e profissional para ajudar você a viver uma vida mais plena e significativa
        </p>
        <div className="flex justify-center gap-4">
          <button className="bg-gradient-to-r from-emerald-600 to-teal-500 text-white px-8 py-3 rounded-full hover:from-emerald-700 hover:to-teal-600 transition-all duration-300 transform hover:scale-105 flex items-center gap-2 shadow-lg">
            Agende sua consulta
            <Calendar size={20} />
          </button>
          <button className="bg-gradient-to-r from-white/20 to-white/5 text-white border-2 border-white/20 px-8 py-3 rounded-full hover:from-white/30 hover:to-white/10 transition-all duration-300 transform hover:scale-105 backdrop-blur-sm shadow-lg">
            Conheça nossos serviços
          </button>
        </div>
      </div>
    </div>
  );
};

export default Hero;