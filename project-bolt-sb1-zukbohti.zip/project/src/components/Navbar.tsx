import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed w-full z-50 bg-white/75 backdrop-blur-lg backdrop-saturate-150 supports-[backdrop-filter]:bg-white/75">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <span className="text-2xl font-serif text-emerald-600">PsicoClínica</span>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-gray-700 hover:text-emerald-600">Sobre</a>
            <a href="#" className="text-gray-700 hover:text-emerald-600">Serviços</a>
            <a href="#" className="text-gray-700 hover:text-emerald-600">Blog</a>
            <button className="bg-emerald-600 text-white px-6 py-2 rounded-full hover:bg-emerald-700">
              Agende sua consulta
            </button>
          </div>

          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-700"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white/75 backdrop-blur-lg backdrop-saturate-150">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#" className="block px-3 py-2 text-gray-700">Sobre</a>
            <a href="#" className="block px-3 py-2 text-gray-700">Serviços</a>
            <a href="#" className="block px-3 py-2 text-gray-700">Blog</a>
            <button className="w-full text-left px-3 py-2 text-gray-700">
              Agende sua consulta
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;